import Vue from 'vue'
import * as Antd from 'ant-design-vue/lib'

Vue.use(Antd)
